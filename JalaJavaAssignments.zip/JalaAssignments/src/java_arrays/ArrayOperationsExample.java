package java_arrays;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class ArrayOperationsExample {
	 // Q-1. Sum of array
    public static int sumArray(int[] arr) {
        int sum = 0;
        for (int num : arr) sum += num;
        return sum;
    }

    // Q-2. Average of array
    public static double averageArray(int[] arr) {
        return (double) sumArray(arr) / arr.length;
    }

    // Q-3. Find index of element
    public static int findIndex(int[] arr, int value) {
        for (int i = 0; i < arr.length; i++)
            if (arr[i] == value) return i;
        return -1;
    }

    // 4. Check if array contains value
    public static boolean containsValue(int[] arr, int value) {
        for (int num : arr)
            if (num == value) return true;
        return false;
    }

    // Q-5. Remove specific element
    public static int[] removeElement(int[] arr, int value) {
        return Arrays.stream(arr).filter(e -> e != value).toArray();
    }

    // Q-6. Copy array
    public static int[] copyArray(int[] arr) {
        return Arrays.copyOf(arr, arr.length);
    }

    // Q-7. Insert element at specific position
    public static int[] insertElement(int[] arr, int index, int value) {
        int[] result = new int[arr.length + 1];
        for (int i = 0, j = 0; i < result.length; i++) {
            if (i == index) result[i] = value;
            else result[i] = arr[j++];
        }
        return result;
    }

    // Q-8. Find min and max
    public static int[] findMinMax(int[] arr) {
        int min = arr[0], max = arr[0];
        for (int num : arr) {
            if (num < min) min = num;
            if (num > max) max = num;
        }
        return new int[]{min, max};
    }

    // Q-9. Reverse array
    public static int[] reverseArray(int[] arr) {
        int[] rev = new int[arr.length];
        for (int i = 0; i < arr.length; i++)
            rev[i] = arr[arr.length - 1 - i];
        return rev;
    }

    // Q-10. Find duplicates
    public static Set<Integer> findDuplicates(int[] arr) {
        Set<Integer> seen = new HashSet<>();
        Set<Integer> duplicates = new HashSet<>();
        for (int num : arr) {
            if (!seen.add(num)) duplicates.add(num);
        }
        return duplicates;
    }

    // Q-11. Common elements in two arrays
    public static Set<Integer> findCommon(int[] arr1, int[] arr2) {
        Set<Integer> set1 = new HashSet<>();
        Set<Integer> result = new HashSet<>();
        for (int num : arr1) set1.add(num);
        for (int num : arr2) if (set1.contains(num)) result.add(num);
        return result;
    }

    // Q-12. Remove duplicates and return new array
    public static int[] removeDuplicates(int[] arr) {
        return Arrays.stream(arr).distinct().toArray();
    }

    // Q-13/14. Second largest number
    public static int secondLargest(int[] arr) {
        int first = Integer.MIN_VALUE, second = Integer.MIN_VALUE;
        for (int num : arr) {
            if (num > first) {
                second = first;
                first = num;
            } else if (num > second && num != first) {
                second = num;
            }
        }
        return second == Integer.MIN_VALUE ? -1 : second;
    }

    // Q-15. Count even and odd
    public static int[] countEvenOdd(int[] arr) {
        int even = 0, odd = 0;
        for (int num : arr) {
            if (num % 2 == 0) even++;
            else odd++;
        }
        return new int[]{even, odd};
    }

    // Q-16. Difference of max and min
    public static int differenceMinMax(int[] arr) {
        int[] minMax = findMinMax(arr);
        return minMax[1] - minMax[0];
    }

    // Q-17. Verify if array contains 12 and 23
    public static boolean contains12And23(int[] arr) {
        boolean has12 = false, has23 = false;
        for (int num : arr) {
            if (num == 12) has12 = true;
            if (num == 23) has23 = true;
        }
        return has12 && has23;
    }

    // Q-18. Remove duplicates and return new array (same as #12)
    // Using method removeDuplicates()
    public static int[] removeDuplicates1(int[] arr) {
        return Arrays.stream(arr).distinct().toArray();
    }

    // Q-19. Find missing number in sorted array from 1 to 100
    public static int findMissingNumber(int[] arr) {
        int n = 100;
        int expectedSum = n * (n + 1) / 2;
        int actualSum = Arrays.stream(arr).sum();
        return expectedSum - actualSum;
    }

    // Main method for demonstration
    public static void main(String[] args) {
        int[] sample = {1, 5, 2, 8, 5, 12, 23, 7, 2};

        System.out.println("1. Sum: " + sumArray(sample));
        System.out.println("2. Average: " + averageArray(sample));
        System.out.println("3. Index of 8: " + findIndex(sample, 8));
        System.out.println("4. Contains 12: " + containsValue(sample, 12));
        System.out.println("5. Remove 5: " + Arrays.toString(removeElement(sample, 5)));
        System.out.println("6. Copy array: " + Arrays.toString(copyArray(sample)));
        System.out.println("7. Insert 99 at index 3: " + Arrays.toString(insertElement(sample, 3, 99)));
        int[] minMax = findMinMax(sample);
        System.out.println("8. Min: " + minMax[0] + ", Max: " + minMax[1]);
        System.out.println("9. Reversed: " + Arrays.toString(reverseArray(sample)));
        System.out.println("10. Duplicates: " + findDuplicates(sample));
        System.out.println("11. Common with {2, 12, 100}: " + findCommon(sample, new int[]{2, 12, 100}));
        System.out.println("12. Removed Duplicates: " + Arrays.toString(removeDuplicates1(sample)));
        System.out.println("13/14. Second Largest: " + secondLargest(sample));
        int[] evenOdd = countEvenOdd(sample);
        System.out.println("15. Even: " + evenOdd[0] + ", Odd: " + evenOdd[1]);
        System.out.println("16. Difference Max-Min: " + differenceMinMax(sample));
        System.out.println("17. Contains 12 and 23: " + contains12And23(sample));

        // 19. Find missing number
        int[] full = new int[99];
        for (int i = 1, j = 0; i <= 100; i++) {
            if (i != 45) full[j++] = i;  // Missing number is 45
        }
        System.out.println("19. Missing Number: " + findMissingNumber(full));
    }
}
