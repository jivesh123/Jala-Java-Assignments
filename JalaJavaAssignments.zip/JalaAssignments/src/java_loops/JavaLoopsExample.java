package java_loops;

import java.util.Scanner;

public class JavaLoopsExample {

	// Q-1. Print “Bright IT Career” ten times using for loop
    public static void printBrightITCareer() {
        for (int i = 1; i <= 10; i++) {
            System.out.println("Bright IT Career");
        }
    }

    // Q-2. Print numbers from 1 to 20 using while loop
    public static void print1To20While() {
        int i = 1;
        while (i <= 20) {
            System.out.print(i + " ");
            i++;
        }
        System.out.println();
    }

    // Q-3. Equal and Not Equal operator
    public static void equalNotEqual(int a, int b) {
        System.out.println("a == b: " + (a == b));
        System.out.println("a != b: " + (a != b));
    }

    // Q-4. Print odd and even numbers between 1 to 20
    public static void printOddEven() {
        for (int i = 1; i <= 20; i++) {
            if (i % 2 == 0)
                System.out.println(i + " is Even");
            else
                System.out.println(i + " is Odd");
        }
    }

    // Q-5. Largest number among three numbers
    public static void largestOfThree(int a, int b, int c) {
        if (a >= b && a >= c)
            System.out.println("Largest: " + a);
        else if (b >= a && b >= c)
            System.out.println("Largest: " + b);
        else
            System.out.println("Largest: " + c);
    }

    // Q-6. Even numbers between 10 and 100 using while
    public static void even10To100While() {
        int i = 10;
        while (i <= 100) {
            if (i % 2 == 0)
                System.out.print(i + " ");
            i++;
        }
        System.out.println();
    }

    // Q-7. Print 1 to 10 using do-while
    public static void print1To10DoWhile() {
        int i = 1;
        do {
            System.out.print(i + " ");
            i++;
        } while (i <= 10);
        System.out.println();
    }

    // Q-8. Armstrong number
    public static void isArmstrong(int num) {
        int sum = 0, temp = num, digit;
        while (temp > 0) {
            digit = temp % 10;
            sum += digit * digit * digit;
            temp /= 10;
        }
        if (sum == num)
            System.out.println(num + " is an Armstrong number.");
        else
            System.out.println(num + " is NOT an Armstrong number.");
    }

    // Q-9. Prime or not
    public static void isPrime(int num) {
        boolean prime = true;
        if (num <= 1) prime = false;
        for (int i = 2; i <= num / 2; i++) {
            if (num % i == 0) {
                prime = false;
                break;
            }
        }
        if (prime)
            System.out.println(num + " is a Prime number.");
        else
            System.out.println(num + " is NOT a Prime number.");
    }

    // Q-10. Palindrome
    public static void isPalindrome(int num) {
        int reverse = 0, temp = num;
        while (temp != 0) {
            int digit = temp % 10;
            reverse = reverse * 10 + digit;
            temp /= 10;
        }
        if (reverse == num)
            System.out.println(num + " is a Palindrome.");
        else
            System.out.println(num + " is NOT a Palindrome.");
    }

    // Q-11. Even or Odd using switch
    public static void evenOddSwitch(int num) {
        switch (num % 2) {
            case 0:
                System.out.println(num + " is Even");
                break;
            case 1:
                System.out.println(num + " is Odd");
                break;
        }
    }

    // Q-12. Gender check using switch
    public static void genderCheck(char gender) {
        switch (Character.toUpperCase(gender)) {
            case 'M':
                System.out.println("Gender: Male");
                break;
            case 'F':
                System.out.println("Gender: Female");
                break;
            default:
                System.out.println("Invalid input. Enter M or F.");
        }
    }

    // Q-13. Multiple if-else: largest in 10, 20, 30
    public static void largestMultipleIfElse(int a, int b, int c) {
        if (a > b && a > c)
            System.out.println("Largest: " + a);
        else if (b > a && b > c)
            System.out.println("Largest: " + b);
        else if (c > a && c > b)
            System.out.println("Largest: " + c);
        else
            System.out.println("Two or more numbers are equal and largest.");
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("1. Print Bright IT Career 10 times:");
        printBrightITCareer();

        System.out.println("\n2. Print numbers 1 to 20 using while:");
        print1To20While();

        System.out.println("\n3. Equal and Not Equal check:");
        equalNotEqual(10, 20);

        System.out.println("\n4. Odd and Even numbers 1-20:");
        printOddEven();

        System.out.println("\n5. Largest among 3 numbers (15, 40, 25):");
        largestOfThree(15, 40, 25);

        System.out.println("\n6. Even numbers between 10 and 100 using while:");
        even10To100While();

        System.out.println("\n7. Print 1 to 10 using do-while:");
        print1To10DoWhile();

        System.out.println("\n8. Check Armstrong number (153):");
        isArmstrong(153);

        System.out.println("\n9. Check Prime (17):");
        isPrime(17);

        System.out.println("\n10. Check Palindrome (121):");
        isPalindrome(121);

        System.out.println("\n11. Even/Odd using switch (5):");
        evenOddSwitch(5);

        System.out.println("\n12. Gender check using switch (Enter M or F):");
        char gender = sc.next().charAt(0);
        genderCheck(gender);

        System.out.println("\n13. Largest using multiple if-else (10, 20, 30):");
        largestMultipleIfElse(10, 20, 30);

        sc.close();
    }

}
