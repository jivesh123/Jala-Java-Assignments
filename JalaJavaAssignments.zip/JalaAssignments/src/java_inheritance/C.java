package java_inheritance;

//Class C (Subclass of B)
public class C extends B {
    String name = "Class C";

    void methodC1() {
        System.out.println("C: methodC1()");
    }

    void methodC2() {
        System.out.println("C: methodC2()");
    }

    @Override
    void commonMethod() {
        System.out.println("C: commonMethod()");
    }
}
