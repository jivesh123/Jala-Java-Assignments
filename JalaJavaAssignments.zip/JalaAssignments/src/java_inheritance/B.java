package java_inheritance;

//Class B (Subclass of A)
public class B extends A {
    String name = "Class B";

    void methodB1() {
        System.out.println("B: methodB1()");
    }

    void methodB2() {
        System.out.println("B: methodB2()");
    }

    @Override
    void commonMethod() {
        System.out.println("B: commonMethod()");
    }
}