package java_inheritance;

//Class A (Super Class)
public class A {
	 // Data member
	 String name = "Class A";
	
	 // Unique methods
	 void methodA1() {
	     System.out.println("A: methodA1()");
	 }
	
	 void methodA2() {
	     System.out.println("A: methodA2()");
	 }
	
	 // Overridden method
	 void commonMethod() {
	     System.out.println("A: commonMethod()");
	 }
}
