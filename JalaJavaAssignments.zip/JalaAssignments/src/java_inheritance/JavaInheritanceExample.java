package java_inheritance;

public class JavaInheritanceExample {
	public static void main(String[] args) {
        // --- Object of Class A ---
        A a = new A();
        System.out.println("\n--- Object of Class A ---");
        a.methodA1();
        a.methodA2();
        a.commonMethod();

        // --- Object of Class B ---
        B b = new B();
        System.out.println("\n--- Object of Class B ---");
        b.methodA1();  // inherited
        b.methodA2();  // inherited
        b.methodB1();
        b.methodB2();
        b.commonMethod();  // overridden

        // --- Object of Class C ---
        C c = new C();
        System.out.println("\n--- Object of Class C ---");
        c.methodA1();  // inherited
        c.methodA2();  // inherited
        c.methodB1();  // inherited
        c.methodB2();  // inherited
        c.methodC1();
        c.methodC2();
        c.commonMethod();  // overridden

        // --- Runtime Polymorphism: Superclass Reference ---
        System.out.println("\n--- Runtime Polymorphism with Methods ---");
        A ref;

        ref = new B();
        ref.commonMethod(); // B's version will be called

        ref = new C();
        ref.commonMethod(); // C's version will be called

        // --- Runtime Polymorphism with Data Members ---
        System.out.println("\n--- Runtime Polymorphism with Data Members ---");

        A refA = new A();
        B refB = new B();
        C refC = new C();

        A refAB = new B();
        A refAC = new C();

        System.out.println("refA.name = " + refA.name);    // Class A
        System.out.println("refB.name = " + refB.name);    // Class B
        System.out.println("refC.name = " + refC.name);    // Class C
        System.out.println("refAB.name = " + refAB.name);  // Class A
        System.out.println("refAC.name = " + refAC.name);  // Class A
    }
}
