package java_strings;

public class JavaStringOperations {
	public static void main(String[] args) {

        // Q-1. Different ways of creating a string
        String s1 = "Hello";                     // String literal
        String s2 = new String("World");         // Using new keyword
        char[] chars = {'J', 'a', 'v', 'a'};
        String s3 = new String(chars);           // From character array

        System.out.println("1. Strings: " + s1 + ", " + s2 + ", " + s3);

        // Q-2. Concatenating two strings using + operator
        String full = s1 + " " + s2;
        System.out.println("2. Concatenated: " + full);

        // Q-3. Finding the length of the string
        System.out.println("3. Length of full: " + full.length());

        // Q-4. Extract a string using substring
        System.out.println("4. Substring (6 to 11): " + full.substring(6, 11));

        // Q-5. Searching in strings using indexOf()
        System.out.println("5. Index of 'World': " + full.indexOf("World"));
        System.out.println("   Index of 'Java': " + full.indexOf("Java"));  // Not found = -1

        // Q-6. Matching string using matches() with regex
        String email = "test@example.com";
        boolean isEmail = email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");
        System.out.println("6. Is valid email: " + isEmail);

        // Q-7. Comparing strings using equals()
        String str1 = "Hello";
        String str2 = "hello";
        System.out.println("7. equals(): " + str1.equals(str2));

        // Q-8. equalsIgnoreCase(), startsWith(), endsWith(), compareTo()
        System.out.println("8. equalsIgnoreCase(): " + str1.equalsIgnoreCase(str2));
        System.out.println("   startsWith(\"He\"): " + str1.startsWith("He"));
        System.out.println("   endsWith(\"lo\"): " + str1.endsWith("lo"));
        System.out.println("   compareTo(\"Hello\"): " + str1.compareTo("Hello"));
        System.out.println("   compareTo(\"World\"): " + str1.compareTo("World"));

        // Q-9. Trimming strings
        String messy = "   trimmed string   ";
        System.out.println("9. Before trim: [" + messy + "]");
        System.out.println("   After trim: [" + messy.trim() + "]");

        // Q-10. Replacing characters in strings
        String replaced = s1.replace('l', 'x');
        System.out.println("10. Replaced 'l' with 'x': " + replaced);

        // Q-11. Splitting strings
        String csv = "apple,banana,grape";
        String[] fruits = csv.split(",");
        System.out.println("11. Split CSV:");
        for (String fruit : fruits) {
            System.out.println(" - " + fruit);
        }

        // Q-12. Converting numbers to strings using valueOf()
        int num = 123;
        String numStr = String.valueOf(num);
        System.out.println("12. valueOf(123): " + numStr);

        // Q-13. Converting Integer object to String
        Integer number = 456;
        String fromInteger = number.toString();
        System.out.println("13. Integer to String: " + fromInteger);

        // Q-14. Converting to uppercase and lowercase
        System.out.println("14. Uppercase: " + str1.toUpperCase());
        System.out.println("    Lowercase: " + str1.toLowerCase());
    }
}
