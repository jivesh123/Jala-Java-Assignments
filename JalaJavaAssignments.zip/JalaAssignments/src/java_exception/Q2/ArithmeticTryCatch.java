package java_exception.Q2;

//Q-2. ArithmeticException with try-catch
public class ArithmeticTryCatch {
	 public static void main(String[] args) {
        try {
            int result = 10 / 0;
        } catch (ArithmeticException e) {
            System.out.println("Caught Exception: " + e);
        }
    }
}
