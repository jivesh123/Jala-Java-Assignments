package java_exception.Q15;

//Q-15. NullPointerException
public class NullPointerEx {
	public static void main(String[] args) {
        String str = null;
        System.out.println(str.length());
    }
}
