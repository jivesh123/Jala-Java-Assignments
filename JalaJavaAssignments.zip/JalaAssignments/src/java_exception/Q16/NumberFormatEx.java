package java_exception.Q16;

//Q-16. NumberFormatException
public class NumberFormatEx {
	public static void main(String[] args) {
        String str = "abc";
        int num = Integer.parseInt(str);
    }
}
