package java_exception.Q7;

//Q-7. Finally block
public class FinallyExample {
	public static void main(String[] args) {
        try {
            int res = 5 / 0;
        } catch (Exception e) {
            System.out.println("Handled Exception");
        } finally {
            System.out.println("Finally block executed");
        }
    }
}
