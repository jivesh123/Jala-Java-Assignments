package java_exception.Q11;

import java.io.FileNotFoundException;
import java.io.FileReader;

//Q-11. FileNotFoundException
public class FileNotFoundEx {
	public static void main(String[] args) throws FileNotFoundException {
        FileReader fr = new FileReader("nonexistent.txt");
    }
}
