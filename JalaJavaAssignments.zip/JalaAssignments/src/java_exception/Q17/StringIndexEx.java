package java_exception.Q17;

//Q-17. StringIndexOutOfBoundsException
public class StringIndexEx {
	public static void main(String[] args) {
        String s = "Java";
        System.out.println(s.charAt(10));
    }
}
