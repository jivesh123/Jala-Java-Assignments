package java_exception.Q3;

//Q-3. Method that throws exception, called without try block
public class ThrowExcep {
	static void risky() throws Exception {
        throw new Exception("This is an exception");
    }
    public static void main(String[] args) throws Exception {
        risky(); // Calling without try-catch, added throws in main
    }
}
