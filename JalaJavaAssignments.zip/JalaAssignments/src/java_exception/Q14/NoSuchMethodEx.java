package java_exception.Q14;

import java.lang.reflect.Method;

public class NoSuchMethodEx {
	 public static void main(String[] args) throws NoSuchMethodException {
        Class<String> cls = String.class;
        Method m = cls.getDeclaredMethod("nonExistentMethod");
    }
}
