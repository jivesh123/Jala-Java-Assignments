package java_exception.Q5;

//Q-5. Throw exception with custom message
public class CustomMessageExample {
	public static void main(String[] args) {
        throw new IllegalArgumentException("Invalid argument provided");
    }
}
