package java_exception.Q12;

import java.io.IOException;

//Q-12. IOException
public class IOExceptionExample {
	public static void main(String[] args) throws IOException {
        throw new IOException("IO error occurred");
    }
}
