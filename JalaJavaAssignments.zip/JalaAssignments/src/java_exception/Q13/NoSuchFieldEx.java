package java_exception.Q13;

import java.lang.reflect.Field;

//Q-13. NoSuchFieldException
public class NoSuchFieldEx {
	public static void main(String[] args) throws NoSuchFieldException {
        Class<String> cls = String.class;
        Field f = cls.getDeclaredField("unknownField");
    }
}
