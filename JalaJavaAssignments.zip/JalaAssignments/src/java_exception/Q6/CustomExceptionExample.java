package java_exception.Q6;

//Q-6. Create your own exception

class MyException extends Exception {
    public MyException(String msg) {
        super(msg);
    }
}

public class CustomExceptionExample {
	public static void main(String[] args) {
        try {
            throw new MyException("This is my custom exception");
        } catch (MyException e) {
            System.out.println("Caught: " + e.getMessage());
        }
    }
}