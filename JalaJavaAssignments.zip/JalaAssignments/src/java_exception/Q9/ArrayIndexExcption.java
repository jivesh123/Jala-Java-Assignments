package java_exception.Q9;

//Q-9. ArrayIndexOutOfBoundsException

public class ArrayIndexExcption {
	public static void main(String[] args) {
        int[] arr = {1, 2, 3};
        System.out.println(arr[5]);
    }
}
