package java_exception.Q18;

import java.sql.SQLException;

//Q-18. SQLException
public class SQLExceptionEx {
	public static void main(String[] args) throws SQLException {
        throw new SQLException("Database error occurred");
    }
}
