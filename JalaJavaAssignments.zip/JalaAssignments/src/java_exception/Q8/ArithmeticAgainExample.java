package java_exception.Q8;

//Q-8. ArithmeticException
public class ArithmeticAgainExample {
	public static void main(String[] args) {
		 System.out.println(100 / 0); // ArithmeticException
	}
}
