package java_exception.Q1;

//Q-1. ArithmeticException without exception handling

public class ArithmeticExcep {
	public static void main(String[] args) {
        int result = 10 / 0; // Will throw ArithmeticException
        System.out.println(result);
    }
}
