package java_exception.Q10;

//Q-10. ClassNotFoundException

public class ClassNotFoundExceptions {
	public static void main(String[] args) {
        try {
            Class.forName("com.unknown.ClassName");
        } catch (ClassNotFoundException e) {
            System.out.println("Class not found: " + e);
        }
    }
}
