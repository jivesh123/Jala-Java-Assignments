package java_interfaces.Q4th;

public class DemoExample implements Printable, Showable{
	public void print() {
        System.out.println("Printing...");
    }

    public void show() {
        System.out.println("Showing...");
    }

    public static void main(String[] args) {
        DemoExample obj = new DemoExample();
        obj.print();
        obj.show();
    }
}
