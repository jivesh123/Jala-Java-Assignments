package java_interfaces.Q4th;

public interface Printable {
	void print();
}
