package java_interfaces.Q6th;

public class MyClassExample implements MyInterface{
	public static void main(String[] args) {
        MyClassExample obj = new MyClassExample();
        obj.greet(); // Uses default implementation
    }
}
