package java_interfaces.Q6th;

public interface MyInterface {
	default void greet() {
        System.out.println("Hello from default method");
    }
}
