package java_interfaces.Q9th;

public class Outer {
	private interface Secret {
        void secretMethod();
    }

    class Inner implements Secret {
        public void secretMethod() {
            System.out.println("Secret method implementation");
        }

        void callSecret() {
            secretMethod();
        }
    }

    public static void main(String[] args) {
        Outer outer = new Outer();
        Outer.Inner inner = outer.new Inner();
        inner.callSecret();
    }
}
