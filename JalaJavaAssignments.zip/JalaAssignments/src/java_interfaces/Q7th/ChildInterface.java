package java_interfaces.Q7th;

public interface ChildInterface extends ParentInterface {
    void childMethod();
}