package java_interfaces.Q7th;

public class InterfaceImpl  implements ChildInterface {
    public void parentMethod() {
        System.out.println("Parent Method");
    }

    public void childMethod() {
        System.out.println("Child Method");
    }

    public static void main(String[] args) {
        InterfaceImpl obj = new InterfaceImpl();
        obj.parentMethod();
        obj.childMethod();
    }
}