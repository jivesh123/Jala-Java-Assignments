package java_interfaces.Q7th;

public interface ParentInterface {
	void parentMethod();
}
