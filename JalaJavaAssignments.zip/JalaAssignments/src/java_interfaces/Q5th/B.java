package java_interfaces.Q5th;

public interface B {
	void display();
}
