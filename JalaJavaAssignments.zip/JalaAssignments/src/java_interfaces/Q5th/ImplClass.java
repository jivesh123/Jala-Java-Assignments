package java_interfaces.Q5th;

public class ImplClass implements A, B {
    public void display() {
        System.out.println("Display from both interfaces");
    }

    public static void main(String[] args) {
        ImplClass obj = new ImplClass();
        obj.display();
    }

}
