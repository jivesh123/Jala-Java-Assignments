package java_interfaces.Q5th;

public interface A {
	void display();
}
