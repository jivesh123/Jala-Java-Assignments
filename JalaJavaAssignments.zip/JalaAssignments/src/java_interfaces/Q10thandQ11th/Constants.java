package java_interfaces.Q10thandQ11th;

public interface Constants {
	int MAX = 100; // public static final
    // private int min = 10;  Not allowed
    // protected int mid = 50;  Not allowed
}
