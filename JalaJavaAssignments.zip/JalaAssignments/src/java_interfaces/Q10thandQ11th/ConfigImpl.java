package java_interfaces.Q10thandQ11th;

interface Config {
    static final String APP_NAME = "MyApp";
}

class ConfigImpl {
    public static void main(String[] args) {
        System.out.println("Application: " + Config.APP_NAME);
    }
}
