package java_interfaces.Q8th;

public class InfoImpl implements Info {
    public void displayInfo() {
        System.out.println("Age: " + AGE);
    }

    public static void main(String[] args) {
        InfoImpl obj = new InfoImpl();
        obj.displayInfo();
    }
}