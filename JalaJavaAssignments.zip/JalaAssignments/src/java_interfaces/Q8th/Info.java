package java_interfaces.Q8th;

public interface Info {
	int AGE = 30; // public static final by default
    void displayInfo();
}
