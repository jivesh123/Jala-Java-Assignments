package java_this_super.Q4;

//4. Call argument constructor of current class using this()
public class Example {
	Example() {
        this("Hello from argument constructor"); // calls the constructor with String arg
    }

    Example(String msg) {
        System.out.println(msg);
    }

    public static void main(String[] args) {
        new Example();
    }
}
