package java_this_super.Q1;

//1. Print the fields/instance members of the current class using this and without using object
public class CurrentClass {
	int id = 101;
    String name = "Java";

    void display() {
        System.out.println("ID: " + this.id);
        System.out.println("Name: " + this.name);
    }

    public static void main(String[] args) {
        CurrentClass obj = new CurrentClass();
        obj.display(); // accessing through `this` inside method, not from object outside
    }
}
