package java_this_super.Q6;

//6. Use this and super in methods (not constructors)
class Animal {
    void speak() {
        System.out.println("Animal speaks");
    }
}

class Dog extends Animal {
    int legs = 4;

    void showDetails() {
        this.bark();     // calling current class method
        super.speak();   // calling parent class method
    }

    void bark() {
        System.out.println("Dog barks");
        System.out.println("Legs: " + this.legs);
    }

    public static void main(String[] args) {
        Dog dog = new Dog();
        dog.showDetails();
    }
}

