package java_this_super.Q3;

//3. Call constructor of the current class using this()
public class Sample {
	Sample() {
        this(100); // calls parameterized constructor
        System.out.println("Default Constructor");
    }

    Sample(int value) {
        System.out.println("Parameterized Constructor with value: " + value);
    }

    public static void main(String[] args) {
        Sample obj = new Sample();
    }
}
