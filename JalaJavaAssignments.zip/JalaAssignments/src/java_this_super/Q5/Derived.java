package java_this_super.Q5;

//5. Call constructor of the parent class using super()
class Base {
    Base() {
        System.out.println("Base class constructor");
    }
}

class Derived extends Base {
    Derived() {
        super(); // calls Base constructor
        System.out.println("Derived class constructor");
    }

    public static void main(String[] args) {
        new Derived();
    }
}

