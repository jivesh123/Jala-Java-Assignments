package java_this_super.Q2;

//2. Print the fields/instance members of the parent class using super
class Parent {
    int age = 50;
    void parentMethod() {
        System.out.println("Parent method");
    }
}

class Child extends Parent {
    int age = 25;

    void print() {
        System.out.println("Parent age: " + super.age); // access parent field
        super.parentMethod(); // access parent method
    }

    public static void main(String[] args) {
        Child obj = new Child();
        obj.print();
    }
}
