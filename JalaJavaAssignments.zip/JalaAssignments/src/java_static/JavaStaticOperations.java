package java_static;

public class JavaStaticOperations {
	// Q-1. Static variables
    static int staticVar1 = 100;
    static String staticVar2 = "Java";

    // Q-1. Instance variables
    int instanceVar1 = 200;
    String instanceVar2 = "Developer";

    // Q-1. Static Method 1
    public static void staticMethod1() {
        System.out.println("Inside staticMethod1");

        // Q-2. Print instance variables in static method using object
        JavaStaticOperations obj = new JavaStaticOperations();
        System.out.println("Accessing instanceVar1 in static method: " + obj.instanceVar1);
        System.out.println("Accessing instanceVar2 in static method: " + obj.instanceVar2);

        // Q-4. Call instance method in static method
        obj.instanceMethod1();
    }

    // Q-1. Static Method 2
    public static void staticMethod2() {
        System.out.println("Inside staticMethod2");
    }

    // Q-1. Instance Method 1
    public void instanceMethod1() {
        System.out.println("Inside instanceMethod1");

        // Q-3. Print static variables in instance method
        System.out.println("Accessing staticVar1 in instance method: " + staticVar1);
        System.out.println("Accessing staticVar2 in instance method: " + staticVar2);

        // Q-5. Call static methods in instance method
        staticMethod2();
    }

    // Q-1. Instance Method 2
    public void instanceMethod2() {
        System.out.println("Inside instanceMethod2");
    }

    // Q-1. Main method
    public static void main(String[] args) {
        System.out.println("Main Method Execution");

        // Create object to access instance members
        JavaStaticOperations obj = new JavaStaticOperations();

        // Q-6. Print all static and instance variables in main method
        System.out.println("StaticVar1: " + staticVar1);
        System.out.println("StaticVar2: " + staticVar2);
        System.out.println("InstanceVar1: " + obj.instanceVar1);
        System.out.println("InstanceVar2: " + obj.instanceVar2);

        // Q-7. Call static methods in main method
        staticMethod1();
        staticMethod2();

        // Q-7. Call instance methods in main method
        obj.instanceMethod1();
        obj.instanceMethod2();
    }
}
