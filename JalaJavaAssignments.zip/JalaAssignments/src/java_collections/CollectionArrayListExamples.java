package java_collections;

import java.util.ArrayList;
import java.util.Iterator;

// -------------------------------
// 1. ArrayList Operations
// -------------------------------
public class CollectionArrayListExamples {
	public static void main(String[] args) {

        System.out.println("== ArrayList ==");
        ArrayList<String> list = new ArrayList<>();

        //1. Add 10 string elements
        for (int i = 1; i <= 10; i++) {
            list.add("Item" + i);
        }

        //2. Add an element
        list.add("ExtraItem");

        //3. Iterate using Iterator
        System.out.println("Iterating ArrayList:");
        Iterator<String> iterator = list.iterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }

        //4. Add at specific index
        list.add(5, "InsertedAt5");

        //5. Remove by value and index
        list.remove("Item3");
        list.remove(2);

        //6. Update at index
        list.set(0, "UpdatedItem1");

        //7. Check if element at index
        System.out.println("Element at index 4: " + list.get(4));

        //8. Get at index
        String elem = list.get(6);
        System.out.println("Element at index 6: " + elem);

        //9. Size
        System.out.println("ArrayList Size: " + list.size());

        //10. Contains
        System.out.println("Contains 'Item5'? " + list.contains("Item5"));

        //11. Remove all
        list.clear();
        System.out.println("ArrayList after clear: " + list);
	}
}
