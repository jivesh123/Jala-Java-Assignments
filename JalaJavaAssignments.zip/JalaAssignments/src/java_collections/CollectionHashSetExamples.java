package java_collections;

import java.util.HashSet;

// -------------------------------
// 3. HashSet Operations
// -------------------------------
public class CollectionHashSetExamples {
	public static void main(String args[]) {
		System.out.println("\n== HashSet ==");
        HashSet<String> set = new HashSet<>();

        //1. Add 10 elements
        for (int i = 1; i <= 10; i++) {
            set.add("Value" + i);
        }

        //2. Add duplicate (ignored)
        set.add("Value5");

        //3. Size
        System.out.println("HashSet size: " + set.size());

        //4. Check contains
        System.out.println("Contains Value7? " + set.contains("Value7"));

        //5. Iterate
        System.out.println("Iterating HashSet:");
        for (String s : set) {
            System.out.println(s);
        }

        //6. Remove
        set.remove("Value2");

        //7. Clone
        HashSet<String> clonedSet = (HashSet<String>) set.clone();
        System.out.println("Cloned Set: " + clonedSet);

        //8. Check empty
        System.out.println("Is empty? " + set.isEmpty());

        //9. Clear all
        set.clear();
        System.out.println("After clear: " + set);
	}
}
