package java_collections;

import java.util.HashMap;

//-------------------------------
// 2. HashMap Operations
// -------------------------------
public class CollectionHashMapExamples {
	public static void main(String args[]) {
		
        System.out.println("\n== HashMap ==");
        HashMap<Integer, String> studentMap = new HashMap<>();

        //1. Add 10 pairs
        for (int i = 1; i <= 10; i++) {
            studentMap.put(i, "Student" + i);
        }

        //2. Insert a new pair
        studentMap.put(11, "NewStudent");

        //3. Fetch value of key
        System.out.println("Value of key 5: " + studentMap.get(5));

        //4. Clone
        HashMap<Integer, String> clonedMap = (HashMap<Integer, String>) studentMap.clone();
        System.out.println("Cloned Map: " + clonedMap);

        //5. Check key
        System.out.println("Contains key 6? " + studentMap.containsKey(6));

        //6. Check value
        System.out.println("Contains value 'Student10'? " + studentMap.containsValue("Student10"));

        //7. Is empty?
        System.out.println("Is map empty? " + studentMap.isEmpty());

        //8. Size
        System.out.println("Map size: " + studentMap.size());

        //9. Print all keys
        System.out.println("Keys: " + studentMap.keySet());

        //10. Print all values
        System.out.println("Values: " + studentMap.values());

        //11. Remove key
        studentMap.remove(3);
        System.out.println("After removing key 3: " + studentMap);

        //12. Copy to another map
        HashMap<Integer, String> anotherMap = new HashMap<>();
        anotherMap.putAll(studentMap);
        System.out.println("Copied map: " + anotherMap);

	}
}
