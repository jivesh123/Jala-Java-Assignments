package java_operators;

public class JavaOperatorsExamples {

	// Q-1. Arithmetic operators
    public static void arithmeticOperators(int a, int b) {
        System.out.println("Addition: " + (a + b));
        System.out.println("Subtraction: " + (a - b));
        System.out.println("Multiplication: " + (a * b));
        System.out.println("Division: " + (a / b));
    }

    // Q-2. Increment and Decrement
    public static void incrementDecrement(int a) {
        System.out.println("Original: " + a);
        System.out.println("Increment: " + (++a));
        System.out.println("Decrement: " + (--a));
    }

    // Q-3. Equal and Not Equal operator
    public static void equalNotEqual(int a, int b) {
        System.out.println("a == b: " + (a == b));
        System.out.println("a != b: " + (a != b));
    }

    // Q-4. Compare if two numbers are equal
    public static void checkEquality(int a, int b) {
        if (a == b) {
            System.out.println("Both numbers are equal.");
        } else {
            System.out.println("Numbers are not equal.");
        }
    }

    // Q-5. Logical operators
    public static void logicalOperators(int x, int y) {
        boolean result1 = (x > 5 && y < 10);  // Logical AND
        boolean result2 = (x > 5 || y < 3);   // Logical OR
        boolean result3 = !(x == y);          // Logical NOT

        System.out.println("Logical AND: " + result1);
        System.out.println("Logical OR: " + result2);
        System.out.println("Logical NOT: " + result3);
    }

    // Q-6. Relational operators
    public static void relationalOperators(int a, int b) {
        System.out.println("a < b: " + (a < b));
        System.out.println("a <= b: " + (a <= b));
        System.out.println("a > b: " + (a > b));
        System.out.println("a >= b: " + (a >= b));
    }

    // Q-7. Print smaller and larger number
    public static void minMax(int a, int b) {
        int smaller = (a < b) ? a : b;
        int larger = (a > b) ? a : b;

        System.out.println("Smaller number: " + smaller);
        System.out.println("Larger number: " + larger);
    }

    public static void main(String[] args) {
        int num1 = 15;
        int num2 = 10;

        System.out.println("1. Arithmetic Operators:");
        arithmeticOperators(num1, num2);

        System.out.println("\n2. Increment and Decrement:");
        incrementDecrement(num1);

        System.out.println("\n3. Equal and Not Equal:");
        equalNotEqual(num1, num2);

        System.out.println("\n4. Equality Check:");
        checkEquality(num1, num2);

        System.out.println("\n5. Logical Operators:");
        logicalOperators(num1, num2);

        System.out.println("\n6. Relational Operators:");
        relationalOperators(num1, num2);

        System.out.println("\n7. Smaller and Larger Number:");
        minMax(num1, num2);
	}
}
