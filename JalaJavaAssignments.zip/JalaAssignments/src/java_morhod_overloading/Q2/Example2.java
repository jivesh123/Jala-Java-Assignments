package java_morhod_overloading.Q2;

//Q-2. Two methods with same name, different number of parameters (different type)
public class Example2 {
    void display(int a) {
        System.out.println("Integer: " + a);
    }

    void display(String s, int a) {
        System.out.println("String and Integer: " + s + ", " + a);
    }

    public static void main(String[] args) {
        Example2 obj = new Example2();
        obj.display(100);
        obj.display("Hello", 200);
    }
}

