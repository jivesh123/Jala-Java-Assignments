package java_morhod_overloading.Q1;

//Q-1. Two methods with same name, different number of parameters (same type)
public class Example1 {
    void print(int a) {
        System.out.println("One int: " + a);
    }

    void print(int a, int b) {
        System.out.println("Two ints: " + a + ", " + b);
    }

    public static void main(String[] args) {
        Example1 obj = new Example1();
        obj.print(10);
        obj.print(10, 20);
    }
}

