package java_morhod_overloading.Q3;

//Q-3. Two methods with same name, same number of parameters (same type)
public class Example3 {
    void test(int a) {
        System.out.println("First test: " + a);
    }

    // ⚠️ Not allowed: same method signature (will cause compilation error)
    /*
    void test(int b) {
        System.out.println("Second test: " + b);
    }
    */

    public static void main(String[] args) {
        Example3 obj = new Example3();
        obj.test(5);  // Only one valid method
    }
}

