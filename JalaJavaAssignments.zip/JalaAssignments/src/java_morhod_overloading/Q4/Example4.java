package java_morhod_overloading.Q4;

//Q-4. Two methods with same name, same number of parameters (different type)
public class Example4 {
    void compute(int a) {
        System.out.println("Integer method: " + a);
    }

    void compute(String s) {
        System.out.println("String method: " + s);
    }

    public static void main(String[] args) {
        Example4 obj = new Example4();
        obj.compute(10);       // Calls int version
        obj.compute("Test");   // Calls String version
    }
}
