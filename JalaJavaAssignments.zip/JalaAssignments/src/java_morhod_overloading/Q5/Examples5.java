package java_morhod_overloading.Q5;

//Q-5. Two methods with same name, same parameters, different return types
public class Examples5 {
    int show(int a) {
        return a * 2;
    }

    // Compilation Error: Duplicate method — return type doesn't differentiate methods
    /*
    String show(int a) {
        return "Value: " + a;
    }
    */

    public static void main(String[] args) {
        Examples5 obj = new Examples5();
        System.out.println(obj.show(10));
    }
}