package java_constructors.Q1;

//Q-1. Write a class with a default constructor, one argument constructor and two argument constructors. Call all from main class
class MyClass {
    MyClass() {
        System.out.println("Default Constructor");
    }

    MyClass(String name) {
        System.out.println("One-arg Constructor: " + name);
    }

    MyClass(String name, int age) {
        System.out.println("Two-arg Constructor: Name = " + name + ", Age = " + age);
    }
}

public class MainClass {
    public static void main(String[] args) {
        new MyClass();                        // default constructor
        new MyClass("Java");                  // one-argument
        new MyClass("Java", 25);              // two-arguments
    }
}
