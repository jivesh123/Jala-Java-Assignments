package java_constructors.Q5;

//Q-5. Try to call constructor multiple times with the same object
public class MultiConstructorExample {
	MultiConstructorExample() {
        System.out.println("Constructor called");
    }

    public static void main(String[] args) {
    	MultiConstructorExample obj = new MultiConstructorExample(); // Constructor called here
        // obj.MultiConstructor(); //  Error: can't call constructor like method

        // To call again, you need a new object
    	MultiConstructorExample obj2 = new MultiConstructorExample();
    }
}
