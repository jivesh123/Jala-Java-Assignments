package java_constructors.Q3;

//Q-3. Apply private, public, protected, and default access modifiers to constructors
class AccessModifierConstructorExample {
    private AccessModifierConstructorExample() {
        System.out.println("Private Constructor");
    }

    public AccessModifierConstructorExample(int a) {
        System.out.println("Public Constructor");
    }

    protected AccessModifierConstructorExample(String s) {
        System.out.println("Protected Constructor");
    }

    AccessModifierConstructorExample(double d) {
        System.out.println("Default Constructor");
    }

    public static void main(String[] args) {
        new AccessModifierConstructorExample();         // Accessible inside same class
        new AccessModifierConstructorExample(5);
        new AccessModifierConstructorExample("Test");
        new AccessModifierConstructorExample(3.14);
    }
}

