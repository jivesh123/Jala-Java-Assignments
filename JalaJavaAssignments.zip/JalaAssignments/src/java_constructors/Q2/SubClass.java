package java_constructors.Q2;

//Q-2. Call the constructors (default and argument) of superclass from a child class

class SuperClass {
    SuperClass() {
        System.out.println("SuperClass Default Constructor");
    }

    SuperClass(String msg) {
        System.out.println("SuperClass Arg Constructor: " + msg);
    }
}

class SubClass extends SuperClass {
    SubClass() {
        super(); // calls default constructor of SuperClass
        System.out.println("SubClass Constructor");
    }

    SubClass(String msg) {
        super(msg); // calls parameterized constructor of SuperClass
        System.out.println("SubClass Arg Constructor");
    }

    public static void main(String[] args) {
        new SubClass();
        new SubClass("Hello from Child");
    }
}
