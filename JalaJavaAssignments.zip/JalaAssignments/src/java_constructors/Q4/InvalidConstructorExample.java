package java_constructors.Q4;

//Q-4. Write constructors with return type int and String (Not allowed in Java)
class InvalidConstructorExample {
    // This is not a constructor — it's a method because of return type
    int InvalidConstructorExample() {
        System.out.println("This is NOT a constructor (int return type)");
        return 1;
    }

    String InvalidConstructorExample(String s) {
        System.out.println("This is NOT a constructor (String return type)");
        return s;
    }

    // Real constructor
    InvalidConstructorExample() {
        System.out.println("Valid constructor");
    }

    public static void main(String[] args) {
        InvalidConstructorExample obj = new InvalidConstructorExample();
        obj.InvalidConstructorExample();
        obj.InvalidConstructorExample("Test");
    }
}

