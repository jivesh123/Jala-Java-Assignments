package java_basics;

public class JavaBasics {
	
	// Q-5. Global variable
    static int value = 100;
    
    // Q-1. Method creation (method signature: public static void displayName())
    public static void displayName() {
        System.out.println("My name is ChatGPT");
    }
    
	public static void main(String args[]) {
		// Q-1. Creating an object of the class
		JavaBasics obj = new JavaBasics();
		
		// Q-2. Print your name
		System.out.println("My Name Is Jivesh Bobde");
		
		// Q-3. Comments
		System.out.println("// This is a single-line comment");

        System.out.println("/*"+
         "\n* This is a multi-line comment"+
         "\n* It can span multiple lines"+
         "\n*/");

        System.out.println("/**"+
         "\n* This is a documentation comment"+
         "\n* It is used to describe methods/classes/interfaces"+
         "\n*/");

        // Q-4. Define and print various data types
        int age = 25;
        boolean isJavaFun = true;
        char grade = 'A';
        float percentage = 89.5f;
        double pi = 3.14159;

        System.out.println("Int: " + age);
        System.out.println("Boolean: " + isJavaFun);
        System.out.println("Char: " + grade);
        System.out.println("Float: " + percentage);
        System.out.println("Double: " + pi);

        // Q-5. Local and global variable with same name
        int value = 50; // Local variable
        System.out.println("Local variable: " + value);           // Prints local
        System.out.println("Global variable: " + JavaBasics.value);   // Access global with class name

        // Q-6. Call function to print name
        obj.displayName();
		
	}
	
}
