package java_IOS.Q11;
import java.io.FileOutputStream;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

//Q-11. Write data to Excel (Apache POI)
public class WriteExcel {
	public static void main(String[] args) throws Exception {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Sheet1");

        Row row = sheet.createRow(0);
        row.createCell(0).setCellValue("Name");
        row.createCell(1).setCellValue("Score");

        Row row1 = sheet.createRow(1);
        row1.createCell(0).setCellValue("John");
        row1.createCell(1).setCellValue(90);

        FileOutputStream fos = new FileOutputStream("output.xlsx");
        workbook.write(fos);
        workbook.close();
        fos.close();
    }
}
