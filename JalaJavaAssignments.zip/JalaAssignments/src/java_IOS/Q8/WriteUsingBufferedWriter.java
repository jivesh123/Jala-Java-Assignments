package java_IOS.Q8;
import java.io.*;

//Q-8. Write using BufferedWriter
public class WriteUsingBufferedWriter {
    public static void main(String[] args) throws IOException {
        BufferedWriter bw = new BufferedWriter(new FileWriter("output.txt"));
        bw.write("Written using BufferedWriter.");
        bw.newLine();
        bw.write("Another line.");
        bw.close();
    }
}
