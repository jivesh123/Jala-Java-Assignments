package java_IOS.Q1;

import java.io.FileInputStream;
import java.io.IOException;

//Q-1. Read text from .txt file using InputStream
public class ReadUsingInputStream {
	public static void main(String[] args) throws IOException {
        FileInputStream fis = new FileInputStream("input.txt");
        int i;
        while ((i = fis.read()) != -1) {
            System.out.print((char) i);
        }
        fis.close();
    }
}
