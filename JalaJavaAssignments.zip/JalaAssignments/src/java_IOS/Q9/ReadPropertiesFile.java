package java_IOS.Q9;
import java.io.*;
import java.util.*;

//Q-9. Read from Properties File
public class ReadPropertiesFile {
    public static void main(String[] args) throws IOException {
        FileReader reader = new FileReader("config.properties");
        Properties prop = new Properties();
        prop.load(reader);
        System.out.println("Username: " + prop.getProperty("username"));
        System.out.println("Password: " + prop.getProperty("password"));
    }
}

