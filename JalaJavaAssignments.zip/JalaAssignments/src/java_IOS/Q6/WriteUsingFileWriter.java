package java_IOS.Q6;
import java.io.*;

//Q-6. Write text using FileWriter
public class WriteUsingFileWriter {
	public static void main(String[] args) throws IOException {
        FileWriter fw = new FileWriter("output.txt");
        fw.write("Text written using FileWriter.");
        fw.close();
    }
}
