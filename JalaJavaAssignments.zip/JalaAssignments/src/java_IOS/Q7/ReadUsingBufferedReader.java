package java_IOS.Q7;

import java.io.*;

//Q-7. Read using BufferedReader
public class ReadUsingBufferedReader {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader("input.txt"));
        String line;
        while ((line = br.readLine()) != null) {
            System.out.println(line);
        }
        br.close();
    }
}

