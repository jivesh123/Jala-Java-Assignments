package java_IOS.Q2;
import java.io.*;

//Q-2. Write text to .txt file using OutputStream
public class WriteUsingOutputStream {
	public static void main(String[] args) throws IOException {
        FileOutputStream fos = new FileOutputStream("output.txt");
        String data = "Hello from OutputStream!";
        fos.write(data.getBytes());
        fos.close();
    }
}
