package java_abstract_class;

public class Dog extends Animal {

    // Implement abstract method
    @Override
    void makeSound() {
        System.out.println("Dog barks");
    }

    public static void main(String[] args) {
        // Creating object of child class
        Dog dog = new Dog();

        // Accessing non-abstract method from abstract class
        dog.eat();  //Output: Animal is eating
        
        // Call abstract method implementation
        dog.makeSound();  // Output: Dog barks
    }
}
