package java_abstract_class;

public abstract class Animal {
	 // Abstract method
    abstract void makeSound();

    // Non-abstract method
    void eat() {
        System.out.println("Animal is eating...");
    }
}
