package java_access_modifire.publicAMOther;

import java_access_modifire.publicAM.PublicDemoExample;

public class DifferentPackagePublicExample {
	public static void main(String[] args) {
        PublicDemoExample obj = new PublicDemoExample();
        System.out.println("Public field: " + obj.publicField);
        obj.publicMethod();
    }
}
