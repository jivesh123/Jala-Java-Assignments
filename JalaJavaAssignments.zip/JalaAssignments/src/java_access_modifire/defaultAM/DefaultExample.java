package java_access_modifire.defaultAM;

public class DefaultExample {
	int defaultField = 10;

    void defaultMethod() {
        System.out.println("Inside default method");
    }
}
