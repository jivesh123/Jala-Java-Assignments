package java_access_modifire.defaultAM;

public class AnotherClassExample {
	 public static void main(String[] args) {
	        DefaultExample obj = new DefaultExample();
	        System.out.println("Default field: " + obj.defaultField);
	        obj.defaultMethod();
	    }
}
