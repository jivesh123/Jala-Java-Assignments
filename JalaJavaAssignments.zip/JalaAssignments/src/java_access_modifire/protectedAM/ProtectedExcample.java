package java_access_modifire.protectedAM;

public class ProtectedExcample {
	protected int protectedField = 50;

    protected void protectedMethod() {
        System.out.println("Inside protected method");
    }
}
