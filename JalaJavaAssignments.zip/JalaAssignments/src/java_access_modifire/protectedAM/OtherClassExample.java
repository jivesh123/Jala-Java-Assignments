package java_access_modifire.protectedAM;

public class OtherClassExample {
	public static void main(String[] args) {
        ProtectedExcample obj = new ProtectedExcample();
        // obj.protectedField;  Not allowed
        // obj.protectedMethod();  Not allowed
    }
}
