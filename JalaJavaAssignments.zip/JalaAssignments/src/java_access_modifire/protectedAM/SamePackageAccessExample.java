package java_access_modifire.protectedAM;

public class SamePackageAccessExample {
	 public static void main(String[] args) {
	        ProtectedExcample obj = new ProtectedExcample();
	        System.out.println("Protected field: " + obj.protectedField);
	        obj.protectedMethod();
	    }
}
