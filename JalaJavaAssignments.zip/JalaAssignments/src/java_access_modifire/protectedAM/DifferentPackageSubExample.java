package java_access_modifire.protectedAM;

public class DifferentPackageSubExample {
	public void accessProtected() {
		ProtectedExcample obj = new ProtectedExcample();
        System.out.println("Protected field: " + obj.protectedField);
        obj.protectedMethod();
    }
}
