package java_access_modifire.publicAM;

public class SamePackagePublic {
	public static void main(String[] args) {
        PublicDemoExample obj = new PublicDemoExample();
        System.out.println("Public field: " + obj.publicField);
        obj.publicMethod();
    }
}
