package java_access_modifire.publicAM;

public class PublicDemoExample {
	 public int publicField = 25;

	 public void publicMethod() {
		 System.out.println("Inside public method");
	 }
}
