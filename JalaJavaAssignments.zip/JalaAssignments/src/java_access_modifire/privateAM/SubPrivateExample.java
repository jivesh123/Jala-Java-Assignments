package java_access_modifire.privateAM;

class SubPrivateExample extends PrivateExample {
    public void display() {
        // Cannot access privateField or privateMethod - compile-time error
        // System.out.println("privateField");      
        // privateMethod();                      
    }
}