package java_access_modifire.privateAM;

public class PrivateExample {

	private int privateField = 100;

    private void privateMethod() {
        System.out.println("Inside private method");
    }

    public static void main(String[] args) {
    	PrivateExample obj = new PrivateExample();
        System.out.println("Private field: " + obj.privateField);
        obj.privateMethod();
    }

}
